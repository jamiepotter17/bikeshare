This project requires the installation of PySimpleGUI as well as pandas.

I made extensive use of pysimplegui.org to help me with the design of the GUI here. 

In addition, I benefitted from examples from StackOverflow and GeekforGeeks. No code is copied, however.